var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

Console.WriteLine(@"
╔═══════════════════════════════════════════════════════════╗
║  VulnerableAPI - Lab Dependency-Check                    ║
║                                                           ║
║  Este proyecto usa DEPENDENCIAS VULNERABLES para         ║
║  práctica de análisis con:                               ║
║  - OWASP Dependency-Check                                ║
║  - Snyk                                                   ║
║  - dotnet list package --vulnerable                      ║
║                                                           ║
║  Vulnerabilidades incluidas:                             ║
║  1. Newtonsoft.Json 9.0.1     (CVE-2018-1000127)        ║
║  2. System.IdentityModel 5.6.0 (Múltiples CVEs)         ║
║  3. Microsoft.Data.SqlClient 2.0.0 (CVE-2021-1636)      ║
╚═══════════════════════════════════════════════════════════╝
");

app.Run();
