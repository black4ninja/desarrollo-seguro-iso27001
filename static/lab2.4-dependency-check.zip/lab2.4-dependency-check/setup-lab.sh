#!/bin/bash

# Script de setup para Lab 2.4 - Análisis de Dependencias
# Este script prepara el entorno del laboratorio

set -e  # Exit on error

echo "🚀 Setup Lab 2.4 - Análisis de Dependencias con OWASP Dependency-Check"
echo "======================================================================"
echo ""

# Obtener directorio del script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# ============================================================
# 1. Verificar herramientas necesarias
# ============================================================
echo "🔍 Paso 1: Verificando herramientas necesarias..."
echo ""

if [ -f "./check-tools.sh" ]; then
    bash ./check-tools.sh
    TOOL_CHECK=$?

    if [ $TOOL_CHECK -eq 1 ]; then
        echo ""
        echo "❌ Setup cancelado: Faltan herramientas obligatorias"
        echo "   Ejecuta las instalaciones necesarias y vuelve a correr este script"
        exit 1
    fi
else
    echo "⚠️  check-tools.sh no encontrado, continuando sin verificación..."
fi

echo ""
echo "============================================================"
echo ""

# ============================================================
# 2. Restaurar dependencias de proyectos
# ============================================================
echo "📦 Paso 2: Restaurando dependencias de NuGet..."
echo ""

if [ -d "./proyecto-vulnerable" ]; then
    echo "   Restaurando proyecto-vulnerable..."
    cd proyecto-vulnerable
    dotnet restore --verbosity quiet
    if [ $? -eq 0 ]; then
        echo "   ✅ proyecto-vulnerable: Dependencias restauradas"
    else
        echo "   ❌ Error restaurando proyecto-vulnerable"
        exit 1
    fi
    cd ..
else
    echo "   ⚠️  proyecto-vulnerable no encontrado"
fi

echo ""

if [ -d "./proyecto-actualizado" ]; then
    echo "   Restaurando proyecto-actualizado..."
    cd proyecto-actualizado
    dotnet restore --verbosity quiet
    if [ $? -eq 0 ]; then
        echo "   ✅ proyecto-actualizado: Dependencias restauradas"
    else
        echo "   ❌ Error restaurando proyecto-actualizado"
        exit 1
    fi
    cd ..
else
    echo "   ⚠️  proyecto-actualizado no encontrado"
fi

echo ""
echo "============================================================"
echo ""

# ============================================================
# 3. Crear carpeta de reportes
# ============================================================
echo "📁 Paso 3: Creando estructura de carpetas..."
echo ""

mkdir -p reportes
mkdir -p reportes-fixed
echo "   ✅ Carpetas creadas:"
echo "      - reportes/        (para reportes de proyecto-vulnerable)"
echo "      - reportes-fixed/  (para reportes de proyecto-actualizado)"

echo ""
echo "============================================================"
echo ""

# ============================================================
# 4. Verificar vulnerabilidades en proyecto-vulnerable
# ============================================================
echo "🔍 Paso 4: Verificando vulnerabilidades en proyecto-vulnerable..."
echo ""

cd proyecto-vulnerable
VULN_OUTPUT=$(dotnet list package --vulnerable 2>&1)

if echo "$VULN_OUTPUT" | grep -q "paquetes vulnerables"; then
    echo "   ✅ Vulnerabilidades detectadas correctamente:"
    echo "$VULN_OUTPUT" | grep -A 10 "paquetes vulnerables" | head -15
else
    echo "   ⚠️  No se detectaron vulnerabilidades esperadas"
    echo "   Esto puede ser normal si las versiones fueron actualizadas"
fi
cd ..

echo ""
echo "============================================================"
echo ""

# ============================================================
# 5. Verificar proyecto-actualizado SIN vulnerabilidades
# ============================================================
echo "✅ Paso 5: Verificando proyecto-actualizado (sin vulnerabilidades)..."
echo ""

cd proyecto-actualizado
SAFE_OUTPUT=$(dotnet list package --vulnerable 2>&1)

if echo "$SAFE_OUTPUT" | grep -q "No se encontraron paquetes vulnerables" || echo "$SAFE_OUTPUT" | grep -q "No vulnerable packages"; then
    echo "   ✅ Proyecto-actualizado: SIN vulnerabilidades detectadas ✓"
else
    echo "   ⚠️  ADVERTENCIA: Proyecto-actualizado aún tiene vulnerabilidades:"
    echo "$SAFE_OUTPUT" | grep -A 5 "paquetes vulnerables" | head -10
    echo ""
    echo "   Esto puede indicar que las versiones necesitan actualización"
fi
cd ..

echo ""
echo "============================================================"
echo ""

# ============================================================
# RESUMEN FINAL
# ============================================================
echo "🎉 SETUP COMPLETADO EXITOSAMENTE"
echo "======================================================================"
echo ""
echo "📋 Estado del laboratorio:"
echo "   ✅ Herramientas verificadas"
echo "   ✅ Dependencias restauradas"
echo "   ✅ Carpetas de reportes creadas"
echo "   ✅ Proyectos validados"
echo ""
echo "📚 Proyectos disponibles:"
echo "   - proyecto-vulnerable/     (Newtonsoft 10.0.1, JWT 5.6.0, SqlClient 2.0.0)"
echo "   - proyecto-actualizado/    (Newtonsoft 13.0.3, JWT 8.15.0, SqlClient 5.1.5)"
echo ""
echo "🚀 Siguiente paso:"
echo "   Sigue el tutorial paso a paso comenzando desde la Parte 1"
echo ""
echo "⏱️  Duración estimada: 75-90 minutos (según herramientas disponibles)"
echo ""
echo "============================================================"
