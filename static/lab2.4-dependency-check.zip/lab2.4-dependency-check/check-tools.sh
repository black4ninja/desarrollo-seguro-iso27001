#!/bin/bash

# Script de verificación de herramientas para Lab 2.4
# Análisis de Dependencias con OWASP Dependency-Check

echo "🔍 Verificando herramientas necesarias para Lab 2.4..."
echo ""

ERRORS=0
WARNINGS=0

# ============================================================
# 1. .NET SDK (OBLIGATORIO)
# ============================================================
echo "📦 Verificando .NET SDK..."
if command -v dotnet &> /dev/null; then
    DOTNET_VERSION=$(dotnet --version)
    echo "   ✅ .NET SDK: $DOTNET_VERSION"

    # Verificar que sea .NET 8.0 o superior
    MAJOR_VERSION=$(echo $DOTNET_VERSION | cut -d'.' -f1)
    if [ "$MAJOR_VERSION" -ge 8 ]; then
        echo "   ✅ Versión compatible (>= 8.0)"
    else
        echo "   ⚠️  Versión antigua detectada. Se recomienda .NET 8.0+"
        WARNINGS=$((WARNINGS + 1))
    fi
else
    echo "   ❌ .NET SDK NO encontrado - REQUERIDO"
    echo "      Instalar: https://dotnet.microsoft.com/download"
    ERRORS=$((ERRORS + 1))
fi
echo ""

# ============================================================
# 2. OWASP Dependency-Check (OPCIONAL pero recomendado)
# ============================================================
echo "🔒 Verificando OWASP Dependency-Check..."
if command -v dependency-check &> /dev/null; then
    DC_VERSION=$(dependency-check --version 2>&1 | grep -oP 'version \K[0-9.]+' || echo "unknown")
    echo "   ✅ OWASP Dependency-Check instalado: v$DC_VERSION"
    echo "   ✅ Parte 2 del lab estará disponible"
else
    echo "   ⚠️  OWASP Dependency-Check NO instalado"
    echo "      Parte 2 del lab NO estará disponible (25 min del tutorial)"
    echo ""
    echo "      Instalación:"
    echo "      - macOS:   brew install dependency-check"
    echo "      - Windows: choco install dependency-check"
    echo "      - Linux:   Ver instrucciones en README.md"
    echo ""
    echo "      ⏱️  Primera instalación: ~15 minutos + 200MB descarga NVD"
    WARNINGS=$((WARNINGS + 1))
fi
echo ""

# ============================================================
# 3. Snyk CLI (OPCIONAL)
# ============================================================
echo "🛡️  Verificando Snyk CLI..."
if command -v snyk &> /dev/null; then
    SNYK_VERSION=$(snyk --version 2>&1)
    echo "   ✅ Snyk CLI instalado: $SNYK_VERSION"

    # Verificar autenticación
    if snyk auth --check &> /dev/null; then
        echo "   ✅ Snyk autenticado correctamente"
    else
        echo "   ⚠️  Snyk instalado pero NO autenticado"
        echo "      Ejecutar: snyk auth"
    fi
else
    echo "   ⚠️  Snyk CLI NO instalado (opcional)"
    echo "      Parte 4 del lab será limitada (solo demo)"
    echo ""
    echo "      Instalación: npm install -g snyk"
    echo "      O visitar: https://snyk.io/"
fi
echo ""

# ============================================================
# 4. Git (para GitHub Dependabot)
# ============================================================
echo "🌐 Verificando Git..."
if command -v git &> /dev/null; then
    GIT_VERSION=$(git --version | grep -oP 'version \K[0-9.]+')
    echo "   ✅ Git instalado: v$GIT_VERSION"
else
    echo "   ⚠️  Git NO instalado"
    echo "      GitHub Dependabot requiere repositorio Git"
fi
echo ""

# ============================================================
# 5. Docker (para alternativa con contenedor)
# ============================================================
echo "🐳 Verificando Docker (opcional)..."
if command -v docker &> /dev/null; then
    if docker info &> /dev/null; then
        DOCKER_VERSION=$(docker --version | grep -oP 'version \K[0-9.]+')
        echo "   ✅ Docker instalado y corriendo: v$DOCKER_VERSION"
        echo "   ✅ Puedes usar contenedor pre-configurado"
    else
        echo "   ⚠️  Docker instalado pero NO está corriendo"
        echo "      Iniciar Docker Desktop o dockerd"
    fi
else
    echo "   ℹ️  Docker NO instalado (opcional)"
    echo "      Alternativa para ambientes con restricciones"
fi
echo ""

# ============================================================
# RESUMEN
# ============================================================
echo "============================================================"
echo "📊 RESUMEN DE VERIFICACIÓN"
echo "============================================================"

if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo "✅ ¡Todas las herramientas están listas!"
    echo "   Puedes ejecutar el Lab 2.4 completo (75 minutos)"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo "⚠️  Herramientas obligatorias OK, pero con advertencias ($WARNINGS)"
    echo ""
    echo "   Puedes continuar con el laboratorio."
    echo "   Las partes opcionales serán demostradas por el facilitador."
    echo ""
    echo "   Tiempo estimado: ~50 minutos (sin Parte 2)"
    exit 0
else
    echo "❌ Faltan herramientas obligatorias ($ERRORS errores)"
    echo ""
    echo "   NO puedes continuar con el laboratorio."
    echo "   Por favor instala las herramientas marcadas con ❌"
    exit 1
fi
