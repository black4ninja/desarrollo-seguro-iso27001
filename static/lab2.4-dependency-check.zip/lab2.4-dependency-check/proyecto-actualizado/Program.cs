var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

Console.WriteLine(@"
╔═══════════════════════════════════════════════════════════╗
║  VulnerableAPI - ACTUALIZADO                             ║
║                                                           ║
║  ✅ Todas las dependencias actualizadas                  ║
║  ✅ Sin CVEs conocidos                                   ║
║                                                           ║
║  Actualizaciones aplicadas:                              ║
║  1. Newtonsoft.Json: 9.0.1 → 13.0.3                     ║
║  2. System.IdentityModel: 5.6.0 → 7.0.3                 ║
║  3. Microsoft.Data.SqlClient: 2.0.0 → 5.1.5             ║
╚═══════════════════════════════════════════════════════════╝
");

app.Run();
