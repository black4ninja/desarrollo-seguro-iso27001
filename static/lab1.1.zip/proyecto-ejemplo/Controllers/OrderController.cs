using Microsoft.AspNetCore.Mvc;
using MiniShop.Models;

namespace MiniShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrderController : ControllerBase
{
    private readonly ILogger<OrderController> _logger;

    // Datos simulados de órdenes
    private static readonly List<Order> _orders = new()
    {
        new Order { Id = 1, UserId = 1, ProductId = 1, Quantity = 2, TotalPrice = 1999.98m, Status = "Completed", OrderDate = DateTime.UtcNow.AddDays(-5) },
        new Order { Id = 2, UserId = 2, ProductId = 2, Quantity = 1, TotalPrice = 29.99m, Status = "Pending", OrderDate = DateTime.UtcNow.AddDays(-2) },
        new Order { Id = 3, UserId = 1, ProductId = 3, Quantity = 3, TotalPrice = 239.97m, Status = "Shipped", OrderDate = DateTime.UtcNow.AddDays(-1) }
    };

    public OrderController(ILogger<OrderController> logger)
    {
        _logger = logger;
    }

    // VULNERABLE #3: Insecure Direct Object Reference (IDOR)
    // OWASP A01:2021 - Broken Access Control
    // CWE-639: Authorization Bypass Through User-Controlled Key
    // ISO 27002:2022 - Control 5.15 (Access control)
    // ISO 27002:2022 - Control 8.3 (Information access restriction)
    // SEVERIDAD: ALTA
    [HttpGet("{orderId}")]
    public IActionResult GetOrder(int orderId)
    {
        // RIESGO: No valida que el usuario autenticado sea el dueño de la orden
        // Cualquier usuario puede ver órdenes de otros cambiando el orderId

        // Simulación: En una app real, obtendríamos el userId del token JWT
        // int currentUserId = GetCurrentUserId();

        var order = _orders.FirstOrDefault(o => o.Id == orderId);

        if (order == null)
        {
            return NotFound("Orden no encontrada");
        }

        // FALTA: Validación de ownership
        // if (order.UserId != currentUserId && !currentUserIsAdmin)
        // {
        //     return Forbid("No tienes permiso para ver esta orden");
        // }

        _logger.LogWarning($"Orden {orderId} accedida sin validación de ownership");

        return Ok(new
        {
            order,
            warning = "Esta orden fue retornada sin validar que pertenezca al usuario autenticado (IDOR)"
        });
    }

    // Endpoint para listar todas las órdenes (también vulnerable)
    [HttpGet]
    public IActionResult GetAllOrders()
    {
        // RIESGO: Retorna TODAS las órdenes sin filtrar por usuario
        // Un usuario podría ver órdenes de todos los demás

        _logger.LogWarning("Se retornaron todas las órdenes sin filtrar por usuario");

        return Ok(new
        {
            orders = _orders,
            warning = "Se retornaron TODAS las órdenes de TODOS los usuarios (IDOR)"
        });
    }

    // Endpoint vulnerable para actualizar estado de orden
    [HttpPut("{orderId}/status")]
    public IActionResult UpdateOrderStatus(int orderId, [FromBody] string newStatus)
    {
        // RIESGO: No valida que el usuario tenga permiso para modificar esta orden

        var order = _orders.FirstOrDefault(o => o.Id == orderId);

        if (order == null)
        {
            return NotFound("Orden no encontrada");
        }

        // FALTA: Validación de permisos
        // Solo el dueño de la orden o un admin deberían poder cambiar el estado

        order.Status = newStatus;

        _logger.LogWarning($"Estado de orden {orderId} modificado sin validación de permisos");

        return Ok(new
        {
            message = "Estado actualizado",
            order,
            warning = "El estado fue actualizado sin validar permisos (IDOR + Broken Access Control)"
        });
    }

    // Endpoint para crear orden (sin validaciones)
    [HttpPost]
    public IActionResult CreateOrder([FromBody] Order order)
    {
        // RIESGO ADICIONAL: El cliente puede especificar el UserId
        // Un atacante podría crear órdenes a nombre de otros usuarios

        order.Id = _orders.Count + 1;
        order.OrderDate = DateTime.UtcNow;

        _orders.Add(order);

        _logger.LogInformation($"Orden {order.Id} creada para usuario {order.UserId}");

        return Ok(new
        {
            message = "Orden creada",
            order,
            warning = "El UserId viene del cliente (Mass Assignment potencial)"
        });
    }
}
