using Microsoft.AspNetCore.Mvc;
using MiniShop.Models;

namespace MiniShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly ILogger<ProductController> _logger;

    public ProductController(ILogger<ProductController> logger)
    {
        _logger = logger;
    }

    // VULNERABLE #1: SQL Injection
    // OWASP A03:2021 - Injection
    // CWE-89: SQL Injection
    // ISO 27002:2022 - Control 8.28 (Secure coding)
    // SEVERIDAD: CRÍTICA
    [HttpGet("search")]
    public IActionResult Search(string keyword)
    {
        // RIESGO: Concatenación directa de string en SQL query
        // Un atacante puede inyectar: ' OR '1'='1
        var query = $"SELECT * FROM Products WHERE Name LIKE '%{keyword}%'";

        // Simulación de ejecución (en app real usaría _db.ExecuteQuery)
        _logger.LogWarning($"Executing unsafe SQL query: {query}");

        return Ok(new {
            message = "Query ejecutado (simulado)",
            query = query,
            warning = "Esta query es vulnerable a SQL Injection"
        });
    }

    // VULNERABLE #5: Missing Input Validation
    // OWASP A03:2021 - Injection (XSS potencial)
    // CWE-20: Improper Input Validation
    // ISO 27002:2022 - Control 8.28 (Secure coding)
    // SEVERIDAD: MEDIA
    [HttpPost]
    public IActionResult CreateProduct([FromBody] Product product)
    {
        // RIESGO: No valida que el precio sea positivo
        // RIESGO: No valida longitud del nombre
        // RIESGO: No sanitiza caracteres especiales (posible XSS si se renderiza en HTML)

        // Simulación de validaciones faltantes
        if (product.Price < 0)
        {
            _logger.LogWarning("Producto creado con precio negativo!");
        }

        if (product.Name.Length > 1000)
        {
            _logger.LogWarning("Producto creado con nombre extremadamente largo!");
        }

        if (product.Name.Contains("<script>"))
        {
            _logger.LogWarning("Posible XSS detectado en nombre del producto!");
        }

        // Simulación de guardado
        _logger.LogInformation($"Producto creado: {product.Name}");

        return Ok(new
        {
            message = "Producto creado (simulado)",
            product = product,
            warnings = new[]
            {
                "No se validó que el precio sea positivo",
                "No se validó la longitud del nombre",
                "No se sanitizaron caracteres especiales (XSS potencial)"
            }
        });
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        // Datos de ejemplo
        var products = new List<Product>
        {
            new Product { Id = 1, Name = "Laptop", Price = 999.99m, Stock = 10 },
            new Product { Id = 2, Name = "Mouse", Price = 29.99m, Stock = 50 },
            new Product { Id = 3, Name = "Teclado", Price = 79.99m, Stock = 25 }
        };

        return Ok(products);
    }
}
