using Microsoft.AspNetCore.Mvc;
using MiniShop.Models;

namespace MiniShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly ILogger<UserController> _logger;

    // Datos simulados de usuarios
    private static readonly List<User> _users = new()
    {
        new User { Id = 1, Username = "admin", Password = "admin123", Email = "admin@minishop.com", IsAdmin = true },
        new User { Id = 2, Username = "user1", Password = "password", Email = "user1@example.com", IsAdmin = false }
    };

    public UserController(ILogger<UserController> logger)
    {
        _logger = logger;
    }

    // VULNERABLE #4: Verbose Error Messages + Plaintext Password
    // OWASP A05:2021 - Security Misconfiguration
    // CWE-209: Information Exposure Through Error Message
    // CWE-256: Plaintext Storage of Password
    // ISO 27002:2022 - Control 8.28 (Secure coding)
    // ISO 27002:2022 - Control 8.24 (Use of cryptography)
    // SEVERIDAD: ALTA
    [HttpPost("login")]
    public IActionResult Login(string username, string password)
    {
        try
        {
            var user = _users.SingleOrDefault(u => u.Username == username);

            // RIESGO #1: Mensaje diferente revela si el usuario existe
            if (user == null)
                return BadRequest("Usuario no encontrado en la base de datos MiniShop");

            // RIESGO #2: Contraseña sin hash (comparación en texto plano)
            if (user.Password != password)
                return BadRequest("Contraseña incorrecta para el usuario proporcionado");

            // RIESGO #3: El mensaje de éxito podría revelar información
            return Ok(new
            {
                message = "Login exitoso",
                userId = user.Id,
                isAdmin = user.IsAdmin
            });
        }
        catch (Exception ex)
        {
            // RIESGO #4: Stack trace expuesto revela estructura interna
            return StatusCode(500, new
            {
                error = ex.Message,
                stackTrace = ex.StackTrace,
                source = ex.Source
            });
        }
    }

    // VULNERABLE #6: Sensitive Data in Logs
    // OWASP A09:2021 - Security Logging and Monitoring Failures
    // CWE-532: Insertion of Sensitive Information into Log File
    // ISO 27002:2022 - Control 8.16 (Monitoring activities)
    // ISO 27002:2022 - Control 8.19 (Security of information in use)
    // SEVERIDAD: MEDIA
    [HttpPost("register")]
    public IActionResult Register(string username, string password, string email)
    {
        // RIESGO: Contraseña en logs de texto plano
        _logger.LogInformation($"Nuevo registro - Usuario: {username}, Password: {password}, Email: {email}");

        // Verificar si el usuario ya existe
        if (_users.Any(u => u.Username == username))
        {
            return BadRequest("El usuario ya existe");
        }

        // RIESGO ADICIONAL: Contraseña se guarda en texto plano
        var newUser = new User
        {
            Id = _users.Count + 1,
            Username = username,
            Password = password, // Sin hash!
            Email = email,
            IsAdmin = false,
            CreatedAt = DateTime.UtcNow
        };

        _users.Add(newUser);

        _logger.LogInformation($"Usuario registrado exitosamente: {username}");

        return Ok(new
        {
            message = "Usuario registrado exitosamente",
            userId = newUser.Id,
            warning = "La contraseña se almacenó en texto plano (INSEGURO)"
        });
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        // Retorna usuarios pero sin contraseñas (al menos esto está bien)
        var usersWithoutPasswords = _users.Select(u => new
        {
            u.Id,
            u.Username,
            u.Email,
            u.IsAdmin,
            u.CreatedAt
        });

        return Ok(usersWithoutPasswords);
    }

    // Endpoint adicional para demostrar exposición de información
    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var user = _users.FirstOrDefault(u => u.Id == id);

        if (user == null)
        {
            // RIESGO: Mensaje específico revela que el ID no existe
            return NotFound($"No se encontró el usuario con ID {id} en la base de datos");
        }

        // Al menos no retorna la contraseña aquí
        return Ok(new
        {
            user.Id,
            user.Username,
            user.Email,
            user.IsAdmin
        });
    }
}
