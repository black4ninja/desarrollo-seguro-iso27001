// VULNERABLE: Missing security headers
// Este archivo contiene configuración básica SIN headers de seguridad
// OWASP A05:2021 - Security Misconfiguration
// ISO 27002:2022 - Control 8.28 (Secure coding)

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// VULNERABLE: No se configuran headers de seguridad
// Faltan:
// - X-Content-Type-Options: nosniff
// - X-Frame-Options: DENY
// - Content-Security-Policy
// - Strict-Transport-Security (HSTS)
// - X-XSS-Protection

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// NOTA: No hay configuración de CORS (podría ser vulnerable)
// NOTA: No hay rate limiting (vulnerable a brute force)
// NOTA: No hay logging de seguridad

app.MapControllers();

app.Run();
