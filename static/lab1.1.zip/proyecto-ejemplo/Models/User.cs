namespace MiniShop.Models;

public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;

    // VULNERABLE: Password stored in plain text
    // OWASP A02:2021 - Cryptographic Failures
    // ISO 27002:2022 - Control 8.24 (Use of cryptography)
    public string Password { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;
    public bool IsAdmin { get; set; }
    public DateTime CreatedAt { get; set; }
}
