namespace MiniShop.Models;

public class Order
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int ProductId { get; set; }
    public int Quantity { get; set; }
    public decimal TotalPrice { get; set; }
    public string Status { get; set; } = "Pending";
    public DateTime OrderDate { get; set; }

    public User? User { get; set; }
    public Product? Product { get; set; }
}
