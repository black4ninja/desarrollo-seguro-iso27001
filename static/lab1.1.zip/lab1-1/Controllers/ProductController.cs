using Microsoft.AspNetCore.Mvc;
using MiniShop.Models;

namespace MiniShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly ILogger<ProductController> _logger;

    public ProductController(ILogger<ProductController> logger)
    {
        _logger = logger;
    }

    [HttpGet("search")]
    public IActionResult Search(string keyword)
    {
        var query = $"SELECT * FROM Products WHERE Name LIKE '%{keyword}%'";

        _logger.LogWarning($"Executing unsafe SQL query: {query}");

        return Ok(new {
            message = "Query ejecutado (simulado)",
            query = query,
            warning = "Esta query es vulnerable a SQL Injection"
        });
    }

    [HttpPost]
    public IActionResult CreateProduct([FromBody] Product product)
    {
        if (product.Price < 0)
        {
            _logger.LogWarning("Producto creado con precio negativo!");
        }

        if (product.Name.Length > 1000)
        {
            _logger.LogWarning("Producto creado con nombre extremadamente largo!");
        }

        if (product.Name.Contains("<script>"))
        {
            _logger.LogWarning("Posible XSS detectado en nombre del producto!");
        }

        _logger.LogInformation($"Producto creado: {product.Name}");

        return Ok(new
        {
            message = "Producto creado (simulado)",
            product = product,
            warnings = new[]
            {
                "No se validó que el precio sea positivo",
                "No se validó la longitud del nombre",
                "No se sanitizaron caracteres especiales (XSS potencial)"
            }
        });
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        var products = new List<Product>
        {
            new Product { Id = 1, Name = "Laptop", Price = 999.99m, Stock = 10 },
            new Product { Id = 2, Name = "Mouse", Price = 29.99m, Stock = 50 },
            new Product { Id = 3, Name = "Teclado", Price = 79.99m, Stock = 25 }
        };

        return Ok(products);
    }
}
