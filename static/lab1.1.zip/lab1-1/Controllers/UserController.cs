using Microsoft.AspNetCore.Mvc;
using MiniShop.Models;

namespace MiniShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly ILogger<UserController> _logger;

    private static readonly List<User> _users = new()
    {
        new User { Id = 1, Username = "admin", Password = "admin123", Email = "admin@minishop.com", IsAdmin = true },
        new User { Id = 2, Username = "user1", Password = "password", Email = "user1@example.com", IsAdmin = false }
    };

    public UserController(ILogger<UserController> logger)
    {
        _logger = logger;
    }

    [HttpPost("login")]
    public IActionResult Login(string username, string password)
    {
        try
        {
            var user = _users.SingleOrDefault(u => u.Username == username);

            if (user == null)
                return BadRequest("Usuario no encontrado en la base de datos MiniShop");

            if (user.Password != password)
                return BadRequest("Contraseña incorrecta para el usuario proporcionado");

            return Ok(new
            {
                message = "Login exitoso",
                userId = user.Id,
                isAdmin = user.IsAdmin
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new
            {
                error = ex.Message,
                stackTrace = ex.StackTrace,
                source = ex.Source
            });
        }
    }

    [HttpPost("register")]
    public IActionResult Register(string username, string password, string email)
    {
        _logger.LogInformation($"Nuevo registro - Usuario: {username}, Password: {password}, Email: {email}");

        if (_users.Any(u => u.Username == username))
        {
            return BadRequest("El usuario ya existe");
        }

        var newUser = new User
        {
            Id = _users.Count + 1,
            Username = username,
            Password = password,
            Email = email,
            IsAdmin = false,
            CreatedAt = DateTime.UtcNow
        };

        _users.Add(newUser);

        _logger.LogInformation($"Usuario registrado exitosamente: {username}");

        return Ok(new
        {
            message = "Usuario registrado exitosamente",
            userId = newUser.Id,
            warning = "La contraseña se almacenó en texto plano (INSEGURO)"
        });
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        var usersWithoutPasswords = _users.Select(u => new
        {
            u.Id,
            u.Username,
            u.Email,
            u.IsAdmin,
            u.CreatedAt
        });

        return Ok(usersWithoutPasswords);
    }

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var user = _users.FirstOrDefault(u => u.Id == id);

        if (user == null)
        {
            return NotFound($"No se encontró el usuario con ID {id} en la base de datos");
        }

        return Ok(new
        {
            user.Id,
            user.Username,
            user.Email,
            user.IsAdmin
        });
    }
}
