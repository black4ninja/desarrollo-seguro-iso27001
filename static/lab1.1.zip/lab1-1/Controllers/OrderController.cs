using Microsoft.AspNetCore.Mvc;
using MiniShop.Models;

namespace MiniShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrderController : ControllerBase
{
    private readonly ILogger<OrderController> _logger;

    private static readonly List<Order> _orders = new()
    {
        new Order { Id = 1, UserId = 1, ProductId = 1, Quantity = 2, TotalPrice = 1999.98m, Status = "Completed", OrderDate = DateTime.UtcNow.AddDays(-5) },
        new Order { Id = 2, UserId = 2, ProductId = 2, Quantity = 1, TotalPrice = 29.99m, Status = "Pending", OrderDate = DateTime.UtcNow.AddDays(-2) },
        new Order { Id = 3, UserId = 1, ProductId = 3, Quantity = 3, TotalPrice = 239.97m, Status = "Shipped", OrderDate = DateTime.UtcNow.AddDays(-1) }
    };

    public OrderController(ILogger<OrderController> logger)
    {
        _logger = logger;
    }

    [HttpGet("{orderId}")]
    public IActionResult GetOrder(int orderId)
    {
        var order = _orders.FirstOrDefault(o => o.Id == orderId);

        if (order == null)
        {
            return NotFound("Orden no encontrada");
        }

        _logger.LogWarning($"Orden {orderId} accedida sin validación de ownership");

        return Ok(new
        {
            order,
            warning = "Esta orden fue retornada sin validar que pertenezca al usuario autenticado (IDOR)"
        });
    }

    [HttpGet]
    public IActionResult GetAllOrders()
    {
        _logger.LogWarning("Se retornaron todas las órdenes sin filtrar por usuario");

        return Ok(new
        {
            orders = _orders,
            warning = "Se retornaron TODAS las órdenes de TODOS los usuarios (IDOR)"
        });
    }

    [HttpPut("{orderId}/status")]
    public IActionResult UpdateOrderStatus(int orderId, [FromBody] string newStatus)
    {
        var order = _orders.FirstOrDefault(o => o.Id == orderId);

        if (order == null)
        {
            return NotFound("Orden no encontrada");
        }

        order.Status = newStatus;

        _logger.LogWarning($"Estado de orden {orderId} modificado sin validación de permisos");

        return Ok(new
        {
            message = "Estado actualizado",
            order,
            warning = "El estado fue actualizado sin validar permisos (IDOR + Broken Access Control)"
        });
    }

    [HttpPost]
    public IActionResult CreateOrder([FromBody] Order order)
    {
        order.Id = _orders.Count + 1;
        order.OrderDate = DateTime.UtcNow;

        _orders.Add(order);

        _logger.LogInformation($"Orden {order.Id} creada para usuario {order.UserId}");

        return Ok(new
        {
            message = "Orden creada",
            order,
            warning = "El UserId viene del cliente (Mass Assignment potencial)"
        });
    }
}
