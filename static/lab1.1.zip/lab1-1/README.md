# MiniShop - API Vulnerable (Versión Sin Comentarios)

Esta es una versión del proyecto MiniShop sin comentarios educativos sobre las vulnerabilidades. Esta versión está diseñada para ser utilizada en ejercicios de auditoría de seguridad donde los estudiantes deben identificar las vulnerabilidades por sí mismos.

## Estructura del Proyecto

```
MiniShop-sin-comentarios/
├── Controllers/
│   ├── UserController.cs       # Gestión de usuarios y autenticación
│   ├── ProductController.cs    # Gestión de productos
│   └── OrderController.cs      # Gestión de órdenes
├── Models/
│   ├── User.cs                 # Modelo de usuario
│   ├── Product.cs              # Modelo de producto
│   └── Order.cs                # Modelo de orden
├── Program.cs                  # Configuración de la aplicación
├── appsettings.json           # Configuración de la aplicación
└── MiniShop.csproj            # Archivo del proyecto .NET
```

## Requisitos

- .NET 10.0 SDK
- Visual Studio 2022 o superior / Visual Studio Code / JetBrains Rider

## Instalación y Ejecución

1. Restaurar dependencias:
```bash
dotnet restore
```

2. Compilar el proyecto:
```bash
dotnet build
```

3. Ejecutar la aplicación:
```bash
dotnet run
```

4. Acceder a Swagger UI:
```
https://localhost:5001/swagger
```

## Endpoints Disponibles

### User Controller
- `POST /api/user/login` - Login de usuario
- `POST /api/user/register` - Registro de usuario
- `GET /api/user` - Listar todos los usuarios
- `GET /api/user/{id}` - Obtener usuario por ID

### Product Controller
- `GET /api/product/search?keyword={keyword}` - Buscar productos
- `POST /api/product` - Crear producto
- `GET /api/product` - Listar todos los productos

### Order Controller
- `GET /api/order/{orderId}` - Obtener orden por ID
- `GET /api/order` - Listar todas las órdenes
- `PUT /api/order/{orderId}/status` - Actualizar estado de orden
- `POST /api/order` - Crear orden

## Objetivo del Ejercicio

Realiza una auditoría de seguridad completa de esta aplicación e identifica:

1. **Vulnerabilidades de inyección**
2. **Problemas de autenticación y autorización**
3. **Exposición de información sensible**
4. **Configuraciones inseguras**
5. **Validación de entrada inadecuada**
6. **Cualquier otra vulnerabilidad de seguridad**

## Usuarios de Prueba

- **Admin**: username: `admin`, password: `admin123`
- **Usuario**: username: `user1`, password: `password`

---

**Nota**: Esta aplicación contiene vulnerabilidades de seguridad intencionales con fines educativos. NO debe ser desplegada en un entorno de producción.
